/*
See LICENSE folder for this sample’s licensing information.
*/

import ARHeadsetKit
import Metal

class MyRenderer: CustomRenderer {
    unowned let renderer: MainRenderer
    
    required init(renderer: MainRenderer, library: MTLLibrary!) {
        self.renderer = renderer
    }
    
    func updateResources() {
        let cone = ARObject(shapeType: .cone,
                            position: [0.0, 0.0, 0.0],
                            scale: [0.2, 0.2, 0.2])
        
        centralRenderer.render(object: cone)
    }
    
    func drawGeometry(renderEncoder: ARMetalRenderCommandEncoder) {
        
    }
}
