import SwiftUI

@main
struct ARHeadsetKit_DocumentationApp: App {
    var body: some Scene {
        WindowGroup {
            fatalError("""
            DO NOT RUN THIS PROJECT. Only use this to build documentation.
            
            If you are opening this project for the first time, update documentation and then start the first tutorial, using the instructions below. In addition, periodically update documentation to ensure you are using the latest version of ARHeadsetKit.
            
            How to Update Documentation:
            
            Right-click on ARHeadsetKit in "Package Dependencies" on the left. Click "Update Package". Then, press Cmd + B to rebuild documentation. This project is configured so that you can use that shortcut instead of Cmd + Ctrl + Shift + D, which is more difficult to remember and use.
            
            How to Start the First Tutorial:
            
            Press Cmd + Shift + 0. In the top left of the project navigator, click on 'Welcome to ARHeadsetKit'. Go to ARHeadsetKit Esentials (Chapter 1) -> Configuring ARHeadsetKit and download the project files. Open the project named "StartingPoint", using the instructions provided in the tutorial.
            """)
        }
    }
}

